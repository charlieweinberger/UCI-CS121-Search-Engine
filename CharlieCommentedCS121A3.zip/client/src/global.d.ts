interface Result {
  url: string
  content: string
}

interface Website {
  url: string
  content: string
  summary: string
}
